#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# NOVA CONVERSATION FIX — apply-patch.sh
# Fixes: deaf-after-speak, no-interruption, echo-loop
#
# USAGE (run from your project root, i.e. the student-hour/ folder):
#   bash apply-patch.sh
#
# Or from anywhere:
#   bash apply-patch.sh /path/to/student-hour
# ─────────────────────────────────────────────────────────────────────────────

set -e

# ── Resolve project root ─────────────────────────────────────────────────────
if [ -n "$1" ]; then
  PROJECT_ROOT="$1"
else
  PROJECT_ROOT="$(pwd)"
fi

TARGET="$PROJECT_ROOT/client/src/pages/ProfessorNovaPage.jsx"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE="$PATCH_DIR/nova-conversation-fix/client/src/pages/ProfessorNovaPage.jsx"

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║          NOVA CONVERSATION FIX — applying patch              ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# ── Verify source exists ─────────────────────────────────────────────────────
if [ ! -f "$SOURCE" ]; then
  echo "❌  Patch file not found at:"
  echo "    $SOURCE"
  echo ""
  echo "    Make sure nova-conversation-fix/ is in the same folder as this script."
  exit 1
fi

# ── Verify target exists ─────────────────────────────────────────────────────
if [ ! -f "$TARGET" ]; then
  echo "❌  Target file not found at:"
  echo "    $TARGET"
  echo ""
  echo "    Run this script from your student-hour/ project root, or pass the path:"
  echo "    bash apply-patch.sh /path/to/student-hour"
  exit 1
fi

# ── Backup original ──────────────────────────────────────────────────────────
BACKUP="${TARGET}.bak_$(date +%Y%m%d_%H%M%S)"
cp "$TARGET" "$BACKUP"
echo "✅  Backed up original to:"
echo "    $BACKUP"
echo ""

# ── Apply fix ────────────────────────────────────────────────────────────────
cp "$SOURCE" "$TARGET"
echo "✅  Applied fixed ProfessorNovaPage.jsx"
echo ""

# ── Summary of what was fixed ────────────────────────────────────────────────
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  FIXES APPLIED:"
echo ""
echo "  1. DEAF AFTER NOVA SPEAKS — fixed"
echo "     earRef.pause() is now only called when an API call starts."
echo "     earRef.resume() is guaranteed in finally{} on every code path."
echo "     The mic can never get stuck in paused state."
echo ""
echo "  2. INTERRUPTION WORKS — fixed"
echo "     TTS now uses a generation counter (_ttsGen)."
echo "     When you speak mid-reply, cancelTTS() bumps the counter,"
echo "     all stale onDone callbacks are silently dropped,"
echo "     and the new sendMessage() proceeds cleanly."
echo ""
echo "  3. ECHO LOOP FIXED — fixed"
echo "     earRef.resume() now takes a settle delay (300ms desktop,"
echo "     500ms mobile). The mic only opens after TTS has been"
echo "     playing for that window, so Nova's voice is not echoed"
echo "     back as a new student message."
echo ""
echo "  4. STATUS BAR HINT — added"
echo "     When Nova is speaking, the status bar now reads:"
echo "     'speaking — tap mic to interrupt'"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  NEXT STEPS:"
echo "    cd $PROJECT_ROOT/client"
echo "    npm run dev          # or your usual start command"
echo ""
echo "  To undo:"
echo "    cp \"$BACKUP\" \"$TARGET\""
echo ""
echo "✅  Done. Happy teaching!"
echo ""
