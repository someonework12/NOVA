# Deployment Guide

## Architecture
- **Frontend (Netlify):** `client/` — React + Vite SPA
- **Backend (Render/Railway):** `server/` — Express + Supabase + Groq

## Step 1: Deploy the Backend First (Render.com — free tier works)
1. Go to https://render.com → New → Web Service
2. Connect your GitHub repo
3. Set these settings:
   - Root Directory: `student-hour/student-hour-p2/server`
   - Build Command: `npm install`
   - Start Command: `node src/index.js`
4. Add environment variables:
   - `SUPABASE_URL` = your Supabase project URL
   - `SUPABASE_SERVICE_ROLE_KEY` = from Supabase → Settings → API
   - `GROQ_API_KEY` = from https://console.groq.com
   - `CLIENT_URL` = your Netlify URL (add after Netlify deploy)
   - `PORT` = 3001
5. Copy the Render URL (e.g. https://nova-api.onrender.com)

## Step 2: Deploy Frontend to Netlify
1. Go to https://netlify.com → Add new site → Import from Git
2. Connect your GitHub repo (NOVA)
3. Build settings:
   - **Base directory:** `student-hour/student-hour-p2/client`
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
4. Add environment variables (Site settings → Environment variables):
   - `VITE_SUPABASE_URL` = your Supabase project URL
   - `VITE_SUPABASE_ANON_KEY` = from Supabase → Settings → API
   - `VITE_API_URL` = your Render backend URL from Step 1
5. Deploy!

## Step 3: Fix the Error You're Seeing Locally
The `supabaseUrl is required` error means your `.env` files are missing.
Run this in your Codespace:
```bash
# In student-hour-p2/server/
cp .env.example .env   # then fill in real values

# In student-hour-p2/client/
cp .env.example .env   # then fill in real values
```
